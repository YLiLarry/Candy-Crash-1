#include "viewabstract.h"
CellViewAbstract:: CellViewAbstract() {
    this->lock = false;
    this->colour = Empty;
    this->cellType = Basic;
}
