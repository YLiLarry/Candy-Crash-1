[11-26-2014 05:32:42]
<p>Pull the master branch and merge to your branch. </p>
<p>I'm synced with the master branch.</p>

<p><code>make clean</code> and <code>make</code>, the double click tests/runSuite. Tell me what you see.</p>

<pre>
TO-DO-LIST:
1. complete test cases
2. update the textview with scores
</pre>
\- Larry
<hr>
[11-19-2014 03:42:42]
Updated board class interface. I think it should be done.
Also checkout the UML branch for updated UML.

\- Wahid

[11-20-2014 04:13:09]
Swapping works, but at the grid level.
The view doesn't reflect the swap.
make and run, notice the grid colours change, but not the view.
ALSO, the colours in the view: 1 is 3 and 3 is 1.

\- Wahid
